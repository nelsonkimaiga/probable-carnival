package com.iFundi.models.extras;

public interface CustomerStats {
	String getMonth();
	int getCount();
}
