package com.iFundi.models.extras;

public interface UsernamesExists {
	String getUsername();
}
